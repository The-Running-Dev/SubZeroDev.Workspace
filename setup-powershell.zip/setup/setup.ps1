[CmdletBinding(SupportsShouldProcess)]
param(
    [ValidateSet('Codex', 'ClaudeCode', 'Both')]
    [string]$Client = 'Both',

    [switch]$SkipClaudeMem,
    [switch]$SkipGitHub,
    [switch]$SkipPlaywright,

    [switch]$IncludeFilesystem,
    [string[]]$FilesystemPath = @(),

    [switch]$IncludeDatabase,
    [string]$DatabaseName,
    [string]$DatabaseCommand,
    [string[]]$DatabaseArgument = @()
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$componentRoot = Join-Path $PSScriptRoot 'scripts\workstation'

function Invoke-SetupScript {
    param(
        [Parameter(Mandatory)][string]$ScriptName,
        [Parameter()][hashtable]$Parameters = @{}
    )
    $scriptPath = Join-Path $componentRoot $ScriptName
    if (-not (Test-Path -LiteralPath $scriptPath -PathType Leaf)) {
        throw "Setup component is missing: $scriptPath"
    }
    Write-Host "`nRunning $ScriptName" -ForegroundColor Magenta
    & $scriptPath @Parameters
}

Invoke-SetupScript -ScriptName 'install-prerequisites.ps1' -Parameters @{
    Client = $Client
    SkipGitHubCli = $SkipGitHub
    WhatIf = $WhatIfPreference
}

Invoke-SetupScript -ScriptName 'install-graphify.ps1' -Parameters @{ WhatIf = $WhatIfPreference }
Invoke-SetupScript -ScriptName 'install-claude-memory.ps1'

if (-not $SkipClaudeMem) {
    Invoke-SetupScript -ScriptName 'install-claude-mem.ps1' -Parameters @{ WhatIf = $WhatIfPreference }
}

if (-not $SkipGitHub) {
    Invoke-SetupScript -ScriptName 'install-github-mcp.ps1' -Parameters @{
        Client = $Client
        WhatIf = $WhatIfPreference
    }
}

if (-not $SkipPlaywright) {
    Invoke-SetupScript -ScriptName 'install-playwright-mcp.ps1' -Parameters @{
        Client = $Client
        WhatIf = $WhatIfPreference
    }
}

if ($IncludeFilesystem) {
    if ($FilesystemPath.Count -eq 0) {
        throw '-IncludeFilesystem requires at least one -FilesystemPath.'
    }
    Invoke-SetupScript -ScriptName 'install-filesystem-mcp.ps1' -Parameters @{
        AllowedPath = $FilesystemPath
        Client = $Client
        WhatIf = $WhatIfPreference
    }
}

if ($IncludeDatabase) {
    if ([string]::IsNullOrWhiteSpace($DatabaseName) -or [string]::IsNullOrWhiteSpace($DatabaseCommand)) {
        throw '-IncludeDatabase requires -DatabaseName and -DatabaseCommand.'
    }
    Invoke-SetupScript -ScriptName 'install-database-mcp.ps1' -Parameters @{
        Name = $DatabaseName
        Command = $DatabaseCommand
        ServerArgument = $DatabaseArgument
        Client = $Client
        WhatIf = $WhatIfPreference
    }
}

Write-Host "`nLLM workspace setup completed." -ForegroundColor Green
Write-Host 'Restart the configured clients, verify MCP connections, and run /memory and /context in Claude Code.'
Write-Host 'GitHub remains read-only and loads GITHUB_PERSONAL_ACCESS_TOKEN from setup\docker\.env through Docker Compose.'
